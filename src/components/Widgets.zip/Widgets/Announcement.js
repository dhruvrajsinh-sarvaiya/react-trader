/* 
    Createdby : Kushal parekh
    Updateby : Kushal parekh
    CreatedDate : 20-09-2018
    UpdatedDate : 20-09-2018
    Description : Announcement Widget
*/

import React, { Component } from 'react'
import Slider from "react-slick";
// intl messages
import IntlMessages from 'Util/IntlMessages';

import { getAnnoucements } from '../../actions';
import { connect } from 'react-redux';

const trendingData = [
   {
      id: 1,
      date: "01",
      month: "July",
      title: "Telecom Commission approved new telecom policy.",
      body: "Dolor sit amet,consectetuer edipiscing elit,sed diam nonummy nibh euismod tinciduntut laoreet doloremagna aliquam erat…"
   },
   {
      id: 2,
      date: "05",
      month: "July",
      title: "Telecom Commission ",
      body: "Dolor sit amet,consectetuer edipiscing elit"
   },
   {
      id: 3,
      date: "07",
      month: "July",
      title: "Approved new telecom policy.",
      body: "Sed diam nonummy nibh euismod tinciduntut laoreet doloremagna aliquam erat…"
   },
   {
      id: 4,
      date: "10",
      month: "July",
      title: "Telecom Commission approved new telecom policy.",
      body: "Dolor sit amet,consectetuer edipiscing elit,sed diam nonummy nibh euismod tinciduntut laoreet doloremagna aliquam erat…"
   },
   {
      id: 5,
      date: "12",
      month:"July",
      title: "Telecom Commission ",
      body: "Dolor sit amet,consectetuer edipiscing elit"
   },
]

class Announcement extends Component {

    constructor(props) {
        super(props);
        // default ui local state
        this.state = {
          annoucements: []
        };
    }

    componentWillMount() {
        console.log("initial");
        this.props.getAnnoucements();
    }

   render() {

        const {annoucements} =this.props;
        const settings = {
            dots: false,
            infinite: true,
            speed: 500,
            slidesToShow: 1,
            slidesToScroll: 1,
            autoplay: true,
            vertical: true,
            responsive: [
                {
                breakpoint: 600,
                settings: {
                    arrows:false
                }
                }
            ]
        };
      return (
         <div className="trending-news-widegt d-flex align-items-center">
            <div className="d-flex align-items-center trending-block">
               <h2 className="mb-0 text-white"><IntlMessages id="widget.annoucement.title" /></h2>
               <i className="zmdi zmdi-flash ml-3 zmdi-hc-2x text-white"></i>
            </div>
            <Slider {...settings} className="p-4">
               {annoucements && annoucements.map((annoucements,key) => (
                  <div className="slider-content" key={annoucements.id}>
                     <div className="d-flex align-items-center ">
                        <div className="month-wrap text-white mr-4 text-center">
                           <span className="date d-block font-2x fw-bold">{annoucements.date}</span>
                           <span className="month font-xs d-block">{annoucements.month}</span>
                        </div>
                        <div className="slider-text-wrap">
                           <h4 className="mb-0 text-white">{annoucements.title}</h4>
                           <p className="mb-0 font-xs text-white">{annoucements.body}</p>
                        </div>
                     </div>
                  </div>
               ))}
            </Slider>
         </div>
      )
   }
}

//export default Faqs;

const mapStateToProps = ({annoucement}) => {
	console.log("annoucement",annoucement);
	const { annoucements } = annoucement;
  	return { annoucements }
}

export default connect(mapStateToProps, {getAnnoucements
})(Announcement);
